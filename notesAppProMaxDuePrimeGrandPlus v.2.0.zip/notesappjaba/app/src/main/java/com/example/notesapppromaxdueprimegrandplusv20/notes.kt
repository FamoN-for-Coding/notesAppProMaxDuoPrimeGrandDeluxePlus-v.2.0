package com.example.notesapppromaxdueprimegrandplusv20

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.LinearLayout
import kotlinx.android.synthetic.main.activity_notes.*

class notes : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_notes)
        addButton.setOnClickListener {
            anim()
            addListItem.setVisibility(View.VISIBLE)
            addButton.setVisibility(View.INVISIBLE)
        }
        addListItemDown.setOnClickListener{
            addListItem.setVisibility(View.INVISIBLE)
            addButton.setVisibility(View.VISIBLE)

        }

        logout.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()

        }
    }
    private fun anim(){
        val loginai = AnimationUtils.loadAnimation(this, R.anim.amosvla)
        val mtavarlay = findViewById(R.id.addListItem) as LinearLayout
        mtavarlay.startAnimation(loginai)
    }

}
