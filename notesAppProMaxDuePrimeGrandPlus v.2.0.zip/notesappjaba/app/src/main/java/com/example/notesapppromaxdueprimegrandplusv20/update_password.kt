package com.example.notesapppromaxdueprimegrandplusv20

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class update_password : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_password)
    }
}
